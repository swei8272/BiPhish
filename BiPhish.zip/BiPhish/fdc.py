import pandas as pd
a = pd.read_csv('Legitimate_url_data_art.csv')
print(a.columns)
b = pd.read_csv('Phishing_url_data_art.csv')
print(b.columns)
# c = pd.read_csv('Legitimate_url_data_cnn.csv')
# print(c)
# d = pd.read_csv('Phishing_url_data_cnn.csv')
# print(d)
a['target']=0
b['target']=1



data = pd.concat([a,b],axis=0)

x= data.iloc[:,1:-1]
# VT
from sklearn.feature_selection import VarianceThreshold
selector = VarianceThreshold(threshold=0.05)
X_selected = selector.fit_transform(x)

selected_feature_names = x.columns[selector.get_support()]
print("retained feature list:", selected_feature_names.tolist())
print("retained feature number:", len(selected_feature_names.tolist()))
X_selected_df = pd.DataFrame(X_selected, columns=selected_feature_names)

# lasso regression to get rid of redundant info
from sklearn.linear_model import LassoCV
lasso = LassoCV(cv=5)
lasso.fit(X_selected_df, data['target'])
print("Lasso regression coffecients:", lasso.coef_)
lasso_coefficients = pd.Series(lasso.coef_, index=X_selected_df.columns)
selected_features = lasso_coefficients[lasso_coefficients != 0]
print("final feature list（through lasso regression）:", selected_features.index.tolist())


x = data.loc[:,['URL_length', 'URL_subdomains',
          'URL_dash', 'URL_numberofCommonTerms',
          'URL_checkNumerical', 'URL_checkSensitiveWord',
          'URL_totalWordUrl', 'URL_shortestWordUrl', 'URL_shortestWordHost',
          'URL_shortestWordPath', 'URL_longestWordUrl', 'URL_longestWordHost',
          'URL_longestWordPath', 'URL_averageWordUrl', 'URL_averageWordHost',
          'URL_averageWordPath', 'URL_checkStatisticRe']]
y = data['target']
print(x)
print(y)
# RFE
from sklearn.feature_selection import RFE
from sklearn.ensemble import  RandomForestClassifier
RF = RandomForestClassifier()
rfe = RFE(estimator=RF, n_features_to_select=10)
X_rfe = rfe.fit_transform(x, y)
print("results after RFE:", X_rfe.shape)

# obtain the feature list
rfe_support = rfe.support_
selected_feature_names = x.columns[rfe_support]

print("feature list throught RFE:", selected_feature_names.tolist())


# feature list after RFE: ['URL_length', 'URL_subdomains', 'URL_totalWordUrl', 'URL_shortestWordPath', 'URL_longestWordUrl',
# 'URL_longestWordHost', 'URL_longestWordPath', 'URL_averageWordUrl', 'URL_averageWordHost', 'URL_averageWordPath']