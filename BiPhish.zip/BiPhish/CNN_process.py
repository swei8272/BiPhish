import torch
from sklearn.metrics import classification_report
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from vocab import read_vocab
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from utils import get_char_ngrams, url_cut, load_data
import pandas as pd
from sklearn.ensemble import RandomForestClassifier as RFC
# from feature_extractor import url_batches


vocab = read_vocab("./vocab.txt")
print(vocab)
Phishing_url_data_path = r"../data/phish-58w.txt"
#Phishing_url_data = np.loadtxt(Phishing_url_data_path)
Phishing_url_data = np.genfromtxt(Phishing_url_data_path,dtype=str, delimiter="\n",encoding='utf-8')
Legitimate_url_data_path = r"../data/legitimate-58w.txt"
#Legitimate_url_data = np.loadtxt(Legitimate_url_data_path)
Legitimate_url_data = np.genfromtxt(Legitimate_url_data_path,dtype=str, delimiter="\n",encoding='utf-8')

train_prop = 0.8
val_prop = 0.1
test_prop = 0.1

class CNN(nn.Module):
    def __init__(self, vocab_size, embedding_dim, num_class):
        super(CNN, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.conv1 = nn.Conv1d(embedding_dim, 64, 3)
        self.conv2 = nn.Conv1d(embedding_dim, 64, 5)
        self.linear = nn.Linear(128, num_class)

    def forward(self, x):
        x = self.embedding(x)

        x1 = F.relu(self.conv1(x.permute(0, 2, 1)))
        x2 = F.relu(self.conv2(x.permute(0, 2, 1)))

        pool1 = F.max_pool1d(x1, kernel_size=x1.shape[2])
        pool2 = F.max_pool1d(x2, kernel_size=x2.shape[2])

        x1 = pool1.squeeze(dim=2)
        x2 = pool2.squeeze(dim=2)
        x = torch.cat([x1, x2], dim=1)
        self.features = x

        x = self.linear(x)
        out = F.log_softmax(x, dim=1)
        return out

def collate_fn(examples):
    inputs = [torch.tensor(ex[0]) for ex in examples]
    targets = torch.tensor([ex[1] for ex in examples], dtype=torch.long)

    inputs = pad_sequence(inputs, batch_first=True)
    return inputs, targets

from vocab import Vocab,save_vocab

def load_sentence_polarity(length):
    # Phishing_url_data = load_data(Phishing_url_data_path)
    # Phishing_url_data = url_cut(Phishing_url_data,length)

    Legitimate_url_data = load_data(Legitimate_url_data_path)
    Legitimate_url_data = url_cut(Legitimate_url_data,length)

    vocab = Vocab.build(Legitimate_url_data)
    save_vocab(vocab,'./vocab.txt')

    Phishing_url_data = [(vocab.convert_tokens_to_ids(sentence), 1)
            for sentence in Legitimate_url_data]
    return Phishing_url_data, vocab

class CnnDataset(Dataset):
    def __init__(self, data):
        self.data = data
    def __len__(self):
        return len(self.data)
    def __getitem__(self, i):
        return self.data[i]
from tqdm.auto import tqdm
def get_part_feature(data):
    Phishing_url_data, vocab = load_sentence_polarity(100)
    train_dataset = CnnDataset(Phishing_url_data)

    inputs = DataLoader(train_dataset, batch_size=256, collate_fn=collate_fn, shuffle=False)
    device = torch.device('cuda')

    model = torch.load("./model_train/model-cc_1.pkl")
    model = model.to('cuda:0')  # 移动模型到GPU
    flag = True
    for batch in tqdm(inputs):
        x, targets = [x.to(device) for x in batch]
        out = model(x.to(device))
        feature = model.features
        array_batch_i = feature.cpu().detach().numpy()
        if flag:
            a = array_batch_i
        else:
            a = np.concatenate((a, array_batch_i))
        flag = False
    return a

#
# urls0 = load_data(Phishing_url_data_path)
# urls0_cnn = pd.DataFrame(get_part_feature(urls0))
# urls0_cnn.to_csv('../Phishing_url_data_cnn.csv',index=False)


urls1 = load_data(Legitimate_url_data_path)
urls1_cnn = pd.DataFrame(get_part_feature(urls1))
# urls1_cnn.to_csv('Legitimate_url_data_cnn.csv',index=False)


# print(urls0_cnn)
# data0 = pd.concat([urls0_art,urls0_cnn],axis=1,ignore_index=True)
# data0['Target'] = 0
# X0_test = data0[:(int)(test_prop * len(data0)):]
# X0_train = data0[(int)(test_prop * len(data0)):]
#
# urls1_art = url_batches(Legitimate_url_data_path)
# data1 = pd.concat([urls1_art,urls1_cnn],axis=1,ignore_index=True)
# data1['Target'] = 1
# X1_test = urls1[:(int)(test_prop * len(data1))]
# X1_train = urls1[(int)(test_prop * len(data1)):]
#
# X_train = pd.concat([X0_train,X1_train],axis=0,ignore_index=True).iloc[:,1:-1]
# X_test = pd.concat([X0_test,X1_test],axis=0,ignore_index=True).iloc[:,1:-1]
# y_train = pd.concat([X0_train,X1_train],axis=0,ignore_index=True).iloc[:,-1]
# y_test = pd.concat([X0_test,X1_test],axis=0,ignore_index=True).iloc[:,-1]
#
# rfc = RFC()
# rfc.fit(X_train, y_train)
#
# y_pre = rfc.predict(X_test)
# print(classification_report(y_test, y_pre, target_names=['legtimate', 'phish'], digits=5))
#
