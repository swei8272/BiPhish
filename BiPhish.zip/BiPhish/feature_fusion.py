import torch
from sklearn.metrics import classification_report
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader, Dataset
from vocab import read_vocab
import numpy as np
from torch.nn.utils.rnn import pad_sequence
from utils import load_data
import pandas as pd
from sklearn.ensemble import RandomForestClassifier as RFC
from feature_extractor import url_batches
from CNN_process import get_part_feature, Phishing_url_data_path,Legitimate_url_data_path


train_prop = 0.8
val_prop = 0.1
test_prop = 0.1


urls0 = load_data(Phishing_url_data_path)
urls0_cnn = pd.DataFrame(get_part_feature(urls0))
urls0_art = url_batches(Phishing_url_data_path)
print(urls0_art)
# print(urls0_cnn)
# data0 = pd.concat([urls0_art,urls0_cnn],axis=1,ignore_index=True)
# data0['Target'] = 0
# X0_test = data0[:(int)(test_prop * len(data0)):]
# X0_train = data0[(int)(test_prop * len(data0)):]
#
#
# urls1 = load_data(Legitimate_url_data_path)
# urls1_cnn = pd.DataFrame(get_part_feature(urls1))
# urls1_art = url_batches(Legitimate_url_data_path)
# data1 = pd.concat([urls1_art,urls1_cnn],axis=1,ignore_index=True)
# data1['Target'] = 1
# X1_test = urls1[:(int)(test_prop * len(data1))]
# X1_train = urls1[(int)(test_prop * len(data1)):]
#
# X_train = pd.concat([X0_train,X1_train],axis=0,ignore_index=True).iloc[:,1:-1]
# X_test = pd.concat([X0_test,X1_test],axis=0,ignore_index=True).iloc[:,1:-1]
# y_train = pd.concat([X0_train,X1_train],axis=0,ignore_index=True).iloc[:,-1]
# y_test = pd.concat([X0_test,X1_test],axis=0,ignore_index=True).iloc[:,-1]
#
# rfc = RFC()
# rfc.fit(X_train, y_train)
#
# y_pre = rfc.predict(X_test)
# print(classification_report(y_test, y_pre, target_names=['legtimate', 'phish'], digits=5))