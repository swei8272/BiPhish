import pandas as pd

a = pd.read_csv('Legitimate_url_data_art.csv')
b = pd.read_csv('Phishing_url_data_art.csv')
c = pd.read_csv('Legitimate_url_data_cnn.csv')
d = pd.read_csv('Phishing_url_data_cnn.csv')


a['target']=0
b['target']=1
c['target']=0
d['target']=1
# ['URL_length', 'URL_subdomains', 'URL_totalWordUrl', 'URL_shortestWordPath', 'URL_longestWordUrl',
# 'URL_longestWordHost', 'URL_longestWordPath', 'URL_averageWordUrl', 'URL_averageWordHost', 'URL_averageWordPath']
cnndata= pd.concat([c,d],axis=0)
artdata= pd.concat([a,b],axis=0)
artdata = artdata[['URL_length', 'URL_subdomains', 'URL_totalWordUrl', 'URL_shortestWordPath', 'URL_longestWordUrl',
'URL_longestWordHost', 'URL_longestWordPath', 'URL_averageWordUrl', 'URL_averageWordHost', 'URL_averageWordPath']]


alldata = pd.concat([cnndata,artdata],axis=1)
print(alldata)
X = alldata.drop('target',axis=1)
y = alldata['target']

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

from sklearnex import patch_sklearn, unpatch_sklearn
patch_sklearn()
from sklearn.metrics import classification_report
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import log_loss
import joblib




logistic_regressor = LogisticRegression()
naive_bayes = GaussianNB()
svm_classifier = SVC(probability=True,kernel='linear')
decision_tree = DecisionTreeClassifier()
random_forest = RandomForestClassifier()


#calculte weights
# logistic_log_loss = log_loss(y_test, logistic_regressor.predict_proba(X_test))
# naive_bayes_log_loss = log_loss(y_test, naive_bayes.predict_proba(X_test))
# svm_log_loss = log_loss(y_test, svm_classifier.predict_proba(X_test))
# decision_tree_loss = log_loss(y_test, decision_tree.predict_proba(X_test))
# random_forest_loss = log_loss(y_test, random_forest.predict_proba(X_test))

# weights = [1 / logistic_log_loss, 1 / naive_bayes_log_loss, 1 / svm_log_loss]

#train each classifier
logistic_regressor.fit(X_train, y_train)
joblib.dump(logistic_regressor, 'logistic_regressor_t.pkl')
naive_bayes.fit(X_train, y_train)
joblib.dump(naive_bayes, 'naive_bayes_t.pkl')
svm_classifier.fit(X_train, y_train)
joblib.dump(svm_classifier, 'svm_classifier_t.pkl')
decision_tree.fit(X_train, y_train)
joblib.dump(decision_tree, 'decision_tree_t.pkl')
random_forest.fit(X_train, y_train)
joblib.dump(random_forest, 'random_forest_t.pkl')

# 预测
# y_pred = svm_classifier.predict(X_test)
# print(classification_report(y_test, y_pred))

# # load saved classifier
logistic_regressor = joblib.load('logistic_regressor_t.pkl')
naive_bayes = joblib.load('naive_bayes_t.pkl')
svm_classifier = joblib.load('svm_classifier_t.pkl')
decision_tree = joblib.load('decision_tree_t.pkl')
random_forest = joblib.load('random_forest_t.pkl')

# set weights for each classifier.
voting_classifier = VotingClassifier(
    estimators=[
        ('logreg', logistic_regressor),
        ('naivebayes', naive_bayes),
        ('svm', svm_classifier),
        ('decisiontree', decision_tree),
        ('randomforest', random_forest)
    ],
    voting='soft', # weighted voting = soft voting with weights
    weights=[1, 1, 2, 1, 2]
    # weights=weights
)

#
voting_classifier.fit(X_train, y_train)  # Fit the VotingClassifier
joblib.dump(voting_classifier, 'voting_classifier.pkl')
y_pred = voting_classifier.predict(X_test)

print(classification_report(y_test, y_pred))

